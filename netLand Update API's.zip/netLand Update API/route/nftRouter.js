const express = require('express');
const router = express.Router();
const NFTController = require('../controller/nftController');
const Auth = require('../middleware/auth')

router.post("/nft",Auth.auth,NFTController.postNFT);

router.get("/getnfts",Auth.auth,NFTController.getAllNFT);
module.exports = router;