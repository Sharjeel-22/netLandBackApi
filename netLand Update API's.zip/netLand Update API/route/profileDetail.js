const express = require('express');
const VerifyToken = require('../middleware/auth');
const router = express.Router();

const ProfileDetail = require('../controller/profileDetail');

router.post("/profiledetail",VerifyToken.auth,ProfileDetail.postProfileDetail);

module.exports = router;