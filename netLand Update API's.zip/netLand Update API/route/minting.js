const express = require('express');
const verify = require('../middleware/auth');
const router = express.Router();
const MintingController = require('../controller/minting');

router.post("/createminting" , MintingController.postMinting);

router.get("/minting",verify.auth,MintingController.getMintingById);

router.get("/mintings",verify.auth,MintingController.getAllMinting);


module.exports = router;