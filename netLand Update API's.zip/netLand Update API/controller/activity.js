const ActivityModel = require('../model/activity');

exports.postActivity = async (req,res,next) =>{
    try{
        let data = req.body;
        const activity = await ActivityModel.create(data);

        if(activity) {
            return res.status(200).json({
                message : "Activity Create Successfully.....",
                hasError : false
            })
        }else{
            return res.status(400).json({
            message : "Activity not created.........!",
            hasError : true
            })
        }
    }catch(error) {
        console.log("============Activity Error============",error);
    }
};
exports.getAllActivites = async(req,res,next) =>{
    try{
        const activity = await ActivityModel.fetchAll();
        if (activity) {
            return res.status(200).json({
                message : "Get All Activity Successfully.......",
                hasError : false,
                "results" : activity
            })
        }else{
            return res.status(400).json({
                message : "All Activity Not Here.....!",
                hasError:true,
                "results" : []
            })
        }
    }catch(error){
        console.log("===========Get All Activity Error===========",error);
    }
}