const UpdatePasswordModel = require('../model/updatePassword');


exports.postPassword = async (req,res,next) =>{
    try {
        let data = req.body;
        const password = await UpdatePasswordModel.create(data);
        if (password) {
            return res.status(200).json({
                message : "Create Password Successfull.....",
                hasError : false
            })
        }else {
            return res.status(400).json({
                message :"Password not create.......!",
                hasError : true
            })
        }
    }catch(error) {
        console.log("===========Password Creating Error===========",error);
    }
}
exports.updatePassword = async (req,res,next) =>{
    try{
       let data = req.body;
       const password = await UpdatePasswordModel.update(data);
       
       if (password) {
           return res.status(200).json({
               message: "Password Change Successfull....",
               hasError:false,
               "results" : password
           })
       }else {
           return res.status(400).json({
               message:"Password not change.....!",
               hasError:true
           })
       }
    }catch(error) {
        console.log("==========Password Update Error==========",error);
    }
}