const MintingModel = require('../model/minting');
const jwt = require('jsonwebtoken');
const env = process.env;
exports.postMinting = async (req,res,next) =>{
    try{
        let data = req.body;

        const minting = await MintingModel.create(data);
        if (minting) {
           const token = jwt.sign(
                {userAddress:minting.userAddress},
                "secret",
                {expiresIn:'1h'}
                )
            return res.status(200).json({
                message:"Minting Create Successfully.....",
                hasError : false,
                token : token
            })
        }else{
            return res.status(400).json({
                message : "Minting not creating.....!",
                hasError : true
            })
        }

    }catch(error) {
        console.log("=========Post minting Error===========",error);
    }
};
exports.getMintingById = async (req,res,next) =>{
    try{
        let id = req.query.id;
        const minting = await MintingModel.fetchById(id);
        if (minting){
            return res.status(200).json({
                message : "Get Minting By Id Successfully.....",
                hasError : false,
                "results" : minting
            })
        }else{
            return res.status(400).json({
                message : "Minting not available this id......!",
                hasError : true,
                "results" : {}
            })
        }
    }catch(error) {
        console.log("===========Get minting by id error===========",error);
    }
}
exports.getAllMinting = async (req,res,next) =>{
    try{
        const mintings = await MintingModel.fetchAll();
        if (mintings) {
            return res.status(200).json({
                message : "Get all minting successfully.....",
                hasError:false,
                "results" : mintings
            })
        }else{
            return res.status(400).json({
                message:"Minting not here........!",
                hasError:true,
                "results": []
            })
        }

    }catch(error){
        console.log("========Get All Minting Error==========",error);
    }
}