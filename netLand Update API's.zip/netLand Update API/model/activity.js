const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const ActivitySchema = new Schema({
    title : String,
    userName : String,
    imageUrl : String ,
    price : String,
    status: {
        type: String,
        enum: [
            "ACTIVE", "INACTIVE", "DELETED"
        ],
        default: "ACTIVE"
    },
}
,
    {
        timestamps: true
    }
);

const ActivityModel = mongoose.model("Activity",ActivitySchema);

module.exports = {
    ActivityModel,
    create : async (body) => {
        let success = false;
        try{
            let activity = await ActivityModel.create({
                title : body.title,
                userName : body.userName ,
                imageUrl : body.imageUrl,
                price : body.price
            });
            if (activity) {
                return activity;
            };
            return success;
        }catch(error){
            console.log("==========Activity post error=========",error);
        }
    },
    fetchAll : async () => {
        try{
            let activity = await ActivityModel.find({status:"ACTIVE"});
            if(activity) {
                return activity;
            }
        }catch(error) {
            console.log("=========Fetch All activity Error======",error);
        }
    }
}