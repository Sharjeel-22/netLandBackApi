const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const profileDetailSchema = new Schema({
    userName : String,
    email: String ,
    firstName : String,
    lastName : String,
    status: {
        type: String,
        enum: [
            "ACTIVE", "INACTIVE", "DELETED"
        ],
        default: "ACTIVE"
    },

}
,
    {
        timestamps: true
    }
)

const ProfileDetailModel = mongoose.model("Profile Detail" , profileDetailSchema);

module.exports = {
    ProfileDetailModel,
    create : async (body) =>{
        let success = false;

        try{
            let profile = await ProfileDetailModel.create({
                userName : body.userName,
                email : body.email,
                firstName : body.firstName,
                lastName : body.lastName
            });
             if (profile) {
                 return profile;
             }
             return success;
        }catch(error) {
            console.log("===========Create profile detail error============",error);
        }
    }
}