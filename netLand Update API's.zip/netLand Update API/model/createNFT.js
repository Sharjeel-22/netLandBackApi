const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const NFTSchema = new Schema({
    uploadFile:String,
    itemName:String,
    description:String,
    royalties:String,
    size:String,
    properties:String,
    scale:String,
    auctionStartDate :Date,
    auctionEndDate :Date,
    status: {
        type: String,
        enum: [
            "ACTIVE", "INACTIVE", "DELETED"
        ],
        default: "ACTIVE"
    },
}
,
    {
        timestamps: true
    }
)

const NFTModel = mongoose.model("NFT",NFTSchema);

module.exports = {
    NFTModel,
    create: async (body) => {
        let success = false;

        try{
            let nft = await NFTModel.create({
                uploadFile:body.uploadFile,
                itemName:body.itemName,
                description:body.description,
                royalties:body.royalties,
                size:body.size,
                properties:body.properties,
                scale:body.scale,
                auctionStartDate : body.auctionStartDate,
                auctionEndDate : body.auctionEndDate
            })
            if(nft) {
                return nft;
            }
            return success;

        }catch(error) {
            console.log("===========Create nft model error===========",error);
        }
    },
    fetchAll : async () =>{
        let nft = await NFTModel.find({
            status: 'ACTIVE'
        });
        if (nft) {
            return nft;
        }
    }
}