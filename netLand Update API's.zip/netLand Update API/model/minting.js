const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const MintingSchema = new Schema({
    name : String,
    description : String,
    imageUrl : String,
    price : String,
    userAddress : String,
    token: String,
    status: {
        type: String,
        enum: [
            "ACTIVE", "INACTIVE", "DELETED"
        ],
        default: "ACTIVE"
    },
}
,
    {
        timestamps: true
    }
);

const MintingModel = mongoose.model("Minting",MintingSchema);

module.exports = {
    MintingModel,
    create : async (body) =>{
        let success = false;
        try{
            let minting = await MintingModel.create({
                name : body.name,
                description : body.description ,
                imageUrl : body.imageUrl,
                price : body.price,
                userAddress : body.userAddress,
                token: body.token
            })
            if (minting) {
                return minting;
            }
            return success;
        }catch(error) {
            console.log("============Create Minting Error===========",error);
        }
    },
    fetchById : async (id) =>{
        try{
            let minting = await MintingModel.findOne({
                _id:id
            })
            if (minting) {
                return minting;
            }
        }catch(error){
            console.log("==========Minting fetch by id erro=========",error);
        }
    },
    fetchAll : async () => {
        try{
            let minting = await MintingModel.find({status : "ACTIVE"});
            if(minting) {
                return minting;
            }
        }catch(error) {
            console.log("=========Fetch all minting error=============",error);
        }
    }
}