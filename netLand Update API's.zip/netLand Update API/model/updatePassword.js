const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const updatePasswordSchema = new Schema({
    oldPassword : String,
    newPassword : String,
    confirmPassword : String,
    select : String,
    status: {
        type: String,
        enum: [
            "ACTIVE", "INACTIVE", "DELETED"
        ],
        default: "ACTIVE"
    },
}

,
    {
        timestamps: true
    }
)

const UpdatePasswordModel = mongoose.model("Change Password",updatePasswordSchema);

module.exports = {
    UpdatePasswordModel,
    create : async (body) =>{
        let success = false;
        try{
            let changePassword = await UpdatePasswordModel.create({
                oldPassword : body.oldPassword,
                newPassword : body.newPassword,
                confirmPassword : body.confirmPassword,
                select : body.select
            });
            if (changePassword) {
                 return changePassword;
            }
            return success;
        }catch(error) {
            console.log("============Change Password Create Error==========",error);
        }
    },
    update : async(body) =>{
        try{
            let password = await UpdatePasswordModel.findOneAndUpdate({
                _id :body.id,

            }
            ,
                {
                    $set: body
                })
                if (password) {
                    return password;
                }
        }catch(error) {
            console.log("===========Change Password Error=============",error);
        }
    }
}