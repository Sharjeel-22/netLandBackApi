const JWT = require('jsonwebtoken');
const minting = require('../model/minting');
const User = require('../model/minting');

exports.auth = async (req, res, next) => {
    const header = req.get("Authorization");
    if (!header || !header.startsWith('Bearer')) {
        return res.status(500).json({
            HasError: true,
            ResultMessages: "Unauthorization access: Token not found",
        });
    }
    const token = header.split(" ")[1];
    const decoded = JWT.verify(token, 'secret');
    const user = decoded;
    if (!user) {
        return res.status(500).json({
            HasError: true,
            ResultMessages: "Unauthorization access: User does not exist",
        });
    }
    next();
}
